import main

print(main.data)
main.run()